<?php
require_once __DIR__ . '/register.php';
require_once __DIR__ . '/login.php';
require_once __DIR__ . '/cart.php';
require_once __DIR__ . '/order.php';
require_once __DIR__ . '/account.php';